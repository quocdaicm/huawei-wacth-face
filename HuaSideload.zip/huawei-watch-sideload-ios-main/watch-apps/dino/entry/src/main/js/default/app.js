export default {
    onCreate() {},
    onDestroy() {}
};
