# CLAUDE.md — ghi chú cho AI làm việc trên HuaSideload

File này tóm tắt app làm gì, đã tìm hiểu được gì từ các repo tham khảo, đã sửa gì và việc còn dở.
Đọc file này trước khi sửa code. Người dùng nói tiếng Việt; trả lời bằng tiếng Việt, ngắn gọn.

## 1. Mục tiêu của người dùng
- Cài file mặt đồng hồ `.hwt` lên **Huawei Watch GT 6 Pro** (tên BLE: `HUAWEI WATCH GT 6 Pro-B03`) **từ iPhone**, không có Android.
- Firmware đồng hồ: **HarmonyOS 6.1.0.118** (bản mới nhất theo Huawei Health, ngày 2026-11-01).
- Người dùng build **trên điện thoại bằng GitHub Actions**: tải `HuaSideload.zip` lên repo (không giải nén) + file `.github/workflows/build.yml`
  (workflow tự `unzip *.zip`, build không ký, xuất `HuaSideload.ipa`). Sau đó tự ký và cài bằng công cụ sideload của họ.
  => Mỗi lần sửa code phải **đóng gói lại thành `HuaSideload.zip`** (thư mục gốc bên trong là `huawei-watch-sideload-ios-main/`) và gửi lại cho họ.
- Không có Swift/Xcode trong môi trường của AI: **code Swift chưa từng được biên dịch**. Người dùng gửi lại log lỗi build nếu có; sửa ngay.

## 2. App làm gì (HuaSideload, SwiftUI, iOS 17+)
Nguồn gốc: https://github.com/Burak4Arslan/huawei-watch-sideload-ios (AGPL-3.0). Port Swift của giao thức Huawei trong Gadgetbridge.
- Nói chuyện với đồng hồ qua **BLE** (service `FE86`, ghi `FE01`, notify `FE02`). Gói tin bắt đầu `0x5A`, CRC16, payload là TLV.
- Ghép đôi bằng HiChain, sau đó mã hóa AES-GCM. Ghi vào BLE tối đa 512 byte trên GT 6 Pro.
- Cài mặt đồng hồ `.hwt` (chỉ gửi `watchface.bin` bên trong, file type 1, qua service `0x28`), cài app đồng hồ `.bin` (lite wearable, cần ký Huawei),
  tải nhạc, thông báo, phát âm thanh iPhone ra loa đồng hồ (CallKit), nhắn tin JSON với app đồng hồ (P2P `0x34`).
- Chỉ **GT 3 SE** từng được tác giả gốc test. GT 6 Pro là HarmonyOS (nền tảng khác), chưa ai xác nhận.
- File chính: `HuaSideload/HuaweiSession.swift` (khung gói, mã hóa, ghép đôi, upload), `HuaweiAuth.swift` (HiChain, PIN),
  `HuaweiFeatures.swift` (hằng số service/lệnh), `WatchLink.swift` (CoreBluetooth + thao tác UI), `WatchFacePackage.swift` (đọc `.hwt`),
  `ContentView.swift` (giao diện), `Localization.swift` + `LocalizationVI.swift` (ngôn ngữ).

## 3. Các repo tham khảo đã xem
1. **huawei-watch-sideload-ios-main** — chính project này.
2. **Gadgetbridge-master** (upstream, Android, Java): nguồn giao thức.
   - Changelog ghi "Initial support for Huawei Watch 6 / 6 Pro". GT 6 / GT 6 Pro: `HuaweiWatchGT6Coordinator` (extends `HuaweiBRCoordinator`, Bluetooth Classic trên Android).
   - **Trên iPhone đồng hồ vẫn phát BLE `FE86`** (đã xác nhận bằng log). Đừng kết luận "iOS không kết nối được" nữa.
   - Cài mặt đồng hồ trong Gadgetbridge: `HuaweiWatchfaceManager`, `packets/Watchface.java`, `HuaweiSupportProvider.java` (~dòng 2629), `AsynchronousResponse.handleWatchface`.
   - Bảng mã màn hình `.hwt` (`description.xml` → `<screen>`) → độ phân giải nằm trong `HuaweiWatchfaceManager.Resolution`. Upstream có thêm `HNHD05`.
   - Trang Gadgetbridge Huawei/Honor ghi lỗi đã biết: **HarmonyOS 6.1 trở lên không cài được mặt đồng hồ** (issue #6199). Chưa rõ nguyên nhân kỹ thuật.
   - Có nhánh **HiChain PAKE/STS** (`GetHiChainPakeRequest`, `HiChainPakeUtils`) cho Honor Watch 5/6 (`supportsHiChainPake()`); GT 6 Pro KHÔNG dùng nhánh này trong upstream.
3. **gadgetbridge-ha-ha-direct-upload** (fork của Gadgetbridge): chỉ thêm đẩy dữ liệu sức khỏe lên Home Assistant và PostgreSQL, phát triển trên đúng GT 6 Pro.
   Phần cài mặt đồng hồ giống upstream (cũ hơn, thiếu `HNHD05`). Không liên quan tới cài `.hwt`.

## 4. Những gì đã thêm vào app (so với bản gốc)
- **Tiếng Việt**: thêm `AppLanguage.vietnamese`; `L(english, turkish)` tra từ điển `VietnameseStrings.table` theo chuỗi tiếng Anh (không có thì hiện tiếng Anh).
- **Workflow GitHub Actions** `.github/workflows/build-ipa.yml` (build không ký). Bản người dùng dùng là `build.yml` đặt ở repo của họ (tự unzip).
- **Xác nhận mặt đồng hồ** (`WatchFace.confirm` + `handleWatchFaceConfirm`): sau khi upload, HarmonyOS gửi `0x27/0x05`; điện thoại phải trả lời
  `0x27/0x05` với tag `01`=tên, `02`=phiên bản, `7F`=`0x000186A0`; nếu `reportType == 2` thì gửi tiếp `0x27/0x03` (tag `03`=1) để kích hoạt. Theo Gadgetbridge. **Chưa kiểm chứng.**
- **Chẩn đoán mặt đồng hồ** (nút ở tab Install): đọc `0x27/0x01` (kích thước màn hình, định dạng file) và `0x27/0x02` (danh sách mặt đang cài), kèm `supportedCommands` cho service `0x27`, `0x28`.
- **Ghi vết giao thức** (công tắc `HuaSideloadTrace`): log mọi gói gửi/nhận sau khi ghép đôi (service, lệnh, TLV), bỏ qua chunk file `0x28/0x06`. Không ghi gói ghép đôi.
- **Lưu log ra file `.txt`** (`LogFile` + `.fileExporter` ở tab Log).
- **Sửa HiChain trên GT 6 Pro** (`HuaweiAuth.parseResponse`): xem mục 5.
- Khi HiChain lỗi, dòng lỗi in cấu trúc TLV của gói trả lời (`describeForDiagnosis`) để dễ debug.

## 5. Kết quả thử trên GT 6 Pro (từ log người dùng gửi)
- Kết nối BLE OK, 5 service: `180F, 3802, CC353442-BE58-4EA2-876E-11D8D6976366, FE86, 180D`. Kênh Huawei sẵn sàng.
- Link params: `Auth 1, support type 4, AES-GCM`. Security negotiation thành công, đồng hồ trả UDID, **pairing type 0x5** (HiChain3: `0x5 ^ 0x01 == 0x04`, code hiện coi là HiChain hợp lệ).
- Bước PIN (`0x01/0x08`) trả mã `0x186A4` rồi `0x01/0x2C` đến và giải mã PIN được (64 byte) → có vẻ bình thường.
- **Bước 4/4 HiChain step 1** (gửi 703 byte, 2 phần): đồng hồ trả 835 byte (`0x01/0x28`), TLV: `01`=JSON 805 byte dạng `{"authForm":0,"payload":{"isoSalt":"…`,
  `02`=01, `03`=8 byte (requestId), `04`=00, `05`=00. App báo "JSON could not be decoded".
  **Giả thuyết**: JSON hợp lệ nhưng có byte thừa ở cuối (ví dụ NUL) làm `JSONSerialization` nghiêm ngặt của iOS từ chối. Đã sửa bằng cách cắt đến `}` cuối cùng. **Chưa biết kết quả.**
- Sau lỗi, đồng hồ bị kẹt phiên ghép đôi (lần thử kế timeout). Cần khởi động lại đồng hồ / tắt bật Bluetooth.
- Nếu iOS báo "Peer removed pairing information": vào Cài đặt iPhone → Bluetooth → ⓘ cạnh đồng hồ → Bỏ qua thiết bị này, rồi thử lại.
- Ghép đôi bằng HuaSideload có thể làm mất kết nối Huawei Health (phải ghép lại Health).

### 5b. Cập nhật 13:11 (log mới): GHÉP ĐÔI THÀNH CÔNG
- Sửa cắt JSON ở `parseResponse` **đã hiệu quả**. Toàn bộ HiChain (bind step 1-4, rồi "Liên kết" step 1,2,4) qua; app báo `ĐÃ GHÉP ĐÔI`. Khóa ghép đôi đã lưu; lần sau tự ghép đôi (pairing type 0x6 khi tái kết nối).
- Thông tin đồng hồ: Model `Atum-B29M`, tên `ATM-B29`, firmware `6.1.0.118(SP10C00M05)`, pin 44%.
- Dịch vụ đồng hồ hỗ trợ: `02 04 07 08 09 0A 0B 0C 0F 14 16 17 18 19 1A 1B 20 25 27 2A 2B 2E 30 32 33 34 35`. **Không có `0x28` (upload file) trong danh sách** — chưa biết có sao không (Gadgetbridge không kiểm tra `0x28`).
- App platform: `type 38 (lite wearable), API 23, OS OpenHarmony 1.0.1, circle, 466x466`. Màn hình 466x466 → `.hwt` mã `HWHD09` (466*466) là hợp.
- Đồng hồ gửi mà app chưa xử lý: `0x34/0x01` (P2P, 124 byte, lúc ~1 s sau khi ghép), `0x0F/0x03` (51 byte, mã hóa; service 0x0F = Weather trong Gadgetbridge nhưng lệnh 0x03 không có trong bảng).
- **Vấn đề mới**: ~43 s sau khi ghép đôi đồng hồ ngắt kết nối (`The specified device has disconnected from us`), người dùng thấy "đồng hồ vẫn thoát". App tự kết nối lại và ghép lại được ngay.
  Lần ghép đôi đầu tiên cũng bị ngắt ngay sau HiChain bind step 4 (có thể do chờ người dùng bấm xác nhận).
- Đã thêm (chưa kiểm chứng): gửi `0x01/0x05` SetTime sau khi ghép (như Gadgetbridge), vòng keep-alive hỏi pin mỗi 20 s khi rảnh, và log các gói đồng hồ gửi mà app không xử lý (mặc định bật).
- Chưa thử cài `.hwt`. Việc kế tiếp: kiểm tra xem kết nối có còn bị ngắt sau 40 s không, rồi bấm "Chẩn đoán mặt đồng hồ", bật ghi vết và cài `.hwt`.

### 5c. Log 13:20-13:25 (đã ghép đôi, nhưng kết nối không ổn định)
- Ghép đôi + tự ghép lại đều OK. Vấn đề: (a) đồng hồ ngắt BLE sau ~42-58 s (2 lần), (b) yêu cầu mã hóa bị từ chối: thông báo (0x02/0x01) và pin (0x01/0x08)
  trả gói **không mã hóa 14 byte** chứa `7F=0x186A4` (100004; thành công là 0x186A0). Phiên thứ 3 không bị ngắt nhưng keep-alive pin không được trả lời / bị 0x186A4 => phiên mã hóa "chết" dù BLE còn nối.
- Loa đồng hồ lỗi vì đồng hồ chưa nối Bluetooth Classic (HFP) với iPhone: không phải lỗi code, cần chạm đồng hồ trong Cài đặt > Bluetooth của iPhone.
- Gói chưa xử lý: `0x0F/0x03`, `0x37/0x02`, `0x07/0x0F`. Chưa biết có liên quan tới việc ngắt hay không.
- Đã sửa (chưa biên dịch/kiểm chứng): hàng đợi ghi BLE có kiểm soát luồng (`canSendWriteWithoutResponse` + `peripheralIsReady`, trước đây iOS có thể âm thầm bỏ gói),
  keep-alive phát hiện phiên chết (2 lần lỗi/timeout liên tiếp, hoặc 0x186A4) rồi tự ngắt và kết nối + ghép lại (`recoverLink`), timeout pin keep-alive 6 s.
- Thêm nút **Quét lỗi kết nối** (tab Install, `WatchLink.selfCheck`): kiểm tra Bluetooth, BLE, kênh FE86, ghép đôi, phiên mã hóa (pin), giờ, dịch vụ 0x27/0x2A/0x25, màn hình; in tóm tắt ✓/✗.
- Việc kế tiếp: gửi log mới; xem dòng "Keep-alive failed" và "đang kết nối lại" xuất hiện khi nào, có tái diễn sau mỗi ~1 phút không.

### 5d. Log 14:26-14:27 (tải .hwt): hash/consult qua, đồng hồ xin đủ chunk rồi KHÔNG gửi `0x28/0x07`
- Đồng hồ xin chunk `0x28/0x05` (đơn vị 0x730 byte, mỗi ~60 ms) tới hết file, sau đó gửi 9 gói **không mã hóa 14 byte** `0x28/0x06` (body 6B, nhiều khả năng `7F=0x186A4`), rồi im 30 s => app báo timeout.
- Sau đó mọi yêu cầu (`0x28/0x02`, pin `0x01/0x08`) đều bị `0x186A4` cho tới khi kết nối lại => đồng hồ kẹt trạng thái sau upload lỗi.
- Nghi vấn: HarmonyOS 6.1 từ chối dữ liệu (liên quan issue Gadgetbridge #6199, có thể cần định dạng/chữ ký khác). Chưa xác nhận.
- Đã sửa (chưa biên dịch): log không còn bị `0x28/0x05` làm tràn (bộ đệm 4000 dòng), in hex body gói chưa xử lý, `handleChunkReply` đọc `7F=code` từ `0x28/0x06` và dừng upload ngay, upload lỗi thì tự kết nối lại sau 2 s (`onUploadFailed`).
- Việc kế tiếp: gửi log đầy đủ của một lần cài (bật Protocol trace) để xem mã thật trong `0x28/0x06`, tham số `0x28/0x04` (unit, encrypt) và chuỗi hash.

### 5e. Log 14:39 (cài Donen sau bản sửa)
- Hash + consult qua (`0x28/0x04`: unit 230, `09=01` => không mã hóa, request 0x730). Đồng hồ xin hết chunk (~13 s) rồi trả 10 gói `0x28/0x06` = `7F04000186A4` (100004) => **từ chối sau khi nhận đủ file** (kiểm tra hash/chữ ký/định dạng?). Cùng kết quả với file kia => không phải do kích thước.
- Gadgetbridge ghi rõ: HarmonyOS 6.1+ không cài được mặt đồng hồ (issue #6199). Gadgetbridge PR #3910: gói HarmonyOS đầy đủ thì gửi nguyên `com.huawei.watchface` (zip), không chỉ `watchface.bin`.
- Thêm công tắc thử nghiệm "gửi nguyên gói com.huawei.watchface" (`HuaSideloadSendInnerPackage`). `.hwt` cũng có file `hashCode` (259 byte) mà app chưa dùng.

### 5f. Log 14:48: **GỬI NGUYÊN GÓI `com.huawei.watchface` THÀNH CÔNG** (`0x28/0x07` result, app báo đã nhận đủ). Công tắc đó giờ bật mặc định. Chưa xác nhận mặt hiện trên đồng hồ; `0x27/0x05` confirm chưa thấy. `0x2A/0x03` (danh sách app) trả 100004 trên GT 6 Pro.

### 5g. Người dùng báo: tải xong không lỗi nhưng mặt không xuất hiện trên đồng hồ. Đã thêm `verifyInstalledFace`: đọc danh sách mặt (0x27/0x02) trước và sau upload, nếu có mặt mới thì gửi 0x27/0x03 kích hoạt, nếu không thì báo rõ.

### 5h. Log 15:08-15:09 (GT 6 Pro) và bản sửa 15:40 (chưa biên dịch)
- Light Speed gửi nguyên gói: đồng hồ nhận đủ (`0x28/0x07`) nhưng sau đó `0x27/0x02` và pin đều trả `0x186A4` (phiên bận/chết); không có `0x27/0x05`. Danh sách đọc về rỗng do lỗi, app báo "KHÔNG cài" là kết luận sai.
- Donen bị `0x186A4` ngay trong phiên vừa ghép đôi lần đầu (pairing type 0x5); lần thử lại hỏng ngay ở lệnh đọc danh sách vì phiên đã chết sau Light Speed. Chưa tách được lỗi phiên với lỗi nội dung. `hashCode` trong `.hwt` khớp hash app gửi.
- Đồng hồ hiện tên theo `description.xml` (`<title>`; Light Speed = "Deneme"), không phải tên file.
- Đã sửa: `HuaweiSession.installedWatchFaces()` (ném lỗi khi có mã lỗi); `verifyInstalledFace` trả true/false/nil, thử đọc lại 3 lần, không còn kết luận "không cài" khi chưa đọc được; thông báo dùng tên trong gói.
- Đã thêm: danh sách mặt đồng hồ trên đồng hồ với nút Dùng/Xóa (`0x27/0x03`, op 1/2; app nhớ tên theo số để hiển thị), ảnh xem trước `preview/cover.jpg` cạnh nút cài, báo lỗi khi picker thất bại, cảnh báo tên file nhạc có dấu / file lớn.
- Đổi tên hiển thị app thành **Huawei Theme** (`CFBundleDisplayName`); bundle ID, target, scheme, `HuaSideload.app/.ipa` giữ nguyên để workflow build của người dùng không hỏng.

### 5i. Log 15:45-15:49 (bản "Huawei Theme" đầu tiên) và bản sửa 16:00 (chưa biên dịch)
- **Phát hiện chính: phiên mã hóa của GT 6 Pro chết khoảng 30 s sau khi ghép đôi** (còn sống ở 29,4 s, chết ở 30,9 s; mọi yêu cầu sau đó trả `0x186A4`, kể cả khi đang tải file). Khớp cả log 15:08: Donen bị từ chối đúng giây thứ 31 sau ghép đôi (do hết phiên, không phải do nội dung gói). Hết phiên, BLE vẫn nối nhưng keep-alive thất bại và app tự nối lại, ghép lại được ngay (pairing type 0x6) và có thêm 30 s.
- Donen gửi nguyên gói trong phiên mới (5 s sau ghép đôi): đồng hồ nhận đủ (`0x28/0x07`), đọc lại danh sách ở 25 s vẫn 15 mặt, **không có mặt mới**, không có `0x27/0x05`. Gadgetbridge #6005 (cập nhật 10/2026): Huawei bỏ đường cài không ký ở HarmonyOS 6.1, bản chính thức tải gói đã ký `contentSign` (RSA, khóa riêng của Huawei) từ server rồi gửi `0x27/0x03` kèm dữ liệu ký trước khi upload; "không còn hướng đi". => Rất có thể app này **không thể cài `.hwt` tự làm lên firmware 6.1.0.118**, không phải lỗi app.
- Danh sách mặt đồng hồ đọc được (15 mặt, id 10 chữ số, 1 mặt `[đang dùng]`). Lệnh Dùng/Xóa (`0x27/0x03` op 1/2) chỉ thử lúc phiên đã hết hạn (`0x186A4`), chưa biết có chạy không.
- Đã sửa: `pairedAt` + `afterFreshSession(needing:)`: trước khi cài theme, tải nhạc, đọc/đổi/xóa mặt đồng hồ, nếu phiên còn ít thời gian hơn việc cần làm thì app tự ngắt, nối lại, ghép lại rồi chạy ngay (`pendingAfterPair`). `verifyInstalledFace` đọc danh sách mỗi 3 s trong lúc phiên còn sống. Thông báo cuối nêu nguyên nhân firmware 6.1.
- Tải nhạc/file lớn hơn ~700 KB sẽ vượt 30 s và có thể bị cắt giữa chừng; thử file < 500 KB trước.
- Chưa thử cách tránh hết phiên (nguyên nhân gốc chưa rõ; nghi chưa trả lời gói P2P `0x34/0x01` mà đồng hồ gửi ngay sau ghép đôi, mỗi phiên số thứ tự trong tag 02 tăng 0003→0004→0005; chỉ là giả thuyết).
- Gói chưa xử lý thấy trong log: `0x37/0x02`, `0x0F/0x04 [01=01 02=01]`, `0x34/0x01`.

## 6. Việc còn dở / bước tiếp theo
1. Nhờ người dùng build bản mới, ghép đôi lại, gửi log. Xem bước 2 HiChain (operation 2), mã hóa phiên, `supportedCommands`.
2. Nếu ghép đôi thành công: chạy "Chẩn đoán mặt đồng hồ", rồi bật ghi vết và cài một `.hwt`; so luồng với Gadgetbridge (`0x28` upload → `0x27/0x05` confirm).
3. Kiểm tra `<screen>` trong `description.xml` của `.hwt` có khớp màn hình GT 6 Pro (độ phân giải đọc từ `0x27/0x01`). Thêm cảnh báo trong app nếu lệch.
4. Nếu đồng hồ từ chối upload ở HarmonyOS 6.1: đây có thể là lỗi firmware (issue Gadgetbridge #6199) chứ không do app. Cách điều tra khác: bắt log HCI trên Android khi Huawei Health cài mặt đồng hồ,
   hoặc debug log giải mã của Gadgetbridge trên Android.
5. Ý tưởng chưa làm: xem trước `.hwt` (`preview/cover.jpg`, `description.xml`), đổi tên/metadata `.hwt` (chỉ là zip; không sửa được hình dạng mặt đồng hồ vì `watchface.bin` là bản biên dịch).
   Muốn tự thiết kế mặt đồng hồ phải dùng Huawei Theme Studio trên máy tính.

## 7. Giới hạn đã biết
- iOS không cho đọc dữ liệu/kết nối của app khác (Huawei Health). Bắt gói BLE bằng hồ sơ Bluetooth logging của Apple có thể làm được nhưng nội dung được mã hóa AES-GCM nên vô ích.
- Huawei Health trên iOS không cài `.hwt` tùy ý, chỉ cài mặt từ cửa hàng.
- Không dùng được Bluetooth Classic trên iOS, nhưng GT 6 Pro vẫn phát BLE `FE86` nên HuaSideload kết nối được.
